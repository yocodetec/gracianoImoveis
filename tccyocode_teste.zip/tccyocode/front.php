<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Pizzaria</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="javinha/javinha.js"></script>
</head>
<body  onload="pizza()">
    <div id="area-cabecalho">
         <div id="area-logo">
         	<h1><span class="branco">Pizzaria</span>Racabikim</h1>
         </div>
         <div id="area-menu">
         	<a href="index.php">Home</a>
         	<a href="pe�aonline.php">Pe�a Online</a>
         	<a href="cadastro.php">Cadastre-se</a>
         </div>
    </div>       
    <div id="area-principal">
            
        <div id="corpo">
            <div id="cx1">
              <a id="slides">
            <img id="pizzaria" class="figuras"/>
            </a>
            </div>   
        </div>       
    </div>
    <div id="area-rodape">
            &copy;Todos os direitos reservados
        </div>      
</body>
</html>
